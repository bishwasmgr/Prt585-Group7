﻿namespace LibraryManagementSystem.BLL;

public class Class1
{

}
