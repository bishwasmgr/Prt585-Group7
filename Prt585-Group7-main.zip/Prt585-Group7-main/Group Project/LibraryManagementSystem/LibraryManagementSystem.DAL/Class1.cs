﻿namespace LibraryManagementSystem.DAL;

public class Class1
{

}
