﻿namespace dream_car_api.Data
{
    public class Car
    {
        public int Id { get; set; }
        public string carName { get; set; }
        public string carDescription { get; set; }
        public string make {  get; set; }
        public string model { get; set; }
        public decimal price { get; set; }
    }
}
