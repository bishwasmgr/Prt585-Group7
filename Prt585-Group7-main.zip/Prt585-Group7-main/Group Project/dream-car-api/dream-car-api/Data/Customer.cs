﻿namespace dream_car_api.Data
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string email { get; set; }
        public string phone { get; set; }


    }
}
