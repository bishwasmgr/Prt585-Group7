﻿namespace dream_car_api.Data
{
    public class Dealer
    {
        public int Id { get; set; } // Primary Key
        public string DealerName { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
    }

}
