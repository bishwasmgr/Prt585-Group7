﻿namespace First_API.Data
{
    public class Product
    {
        public int Id { get; set; }
        public string productName { get; set; }
        public string productDescription { get; set; }
        public string productCategory { get; set; }
        public decimal price { get; set; }
    }
}
