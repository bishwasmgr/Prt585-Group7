﻿namespace First_API.Data
{
    public class ShareHolder
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string email { get; set; }
        public decimal share {  get; set; }
        public string mobile { get; set; }
        

    }
}
