﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MVC_Enrolment_demo.Migrations
{
    /// <inheritdoc />
    public partial class SecondMigration2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
